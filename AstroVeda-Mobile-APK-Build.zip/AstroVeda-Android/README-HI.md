# AstroVeda – Android Studio प्रोजेक्ट

यह आपके दिए गए राशिफल HTML को Android WebView ऐप में पैक करता है।

## APK बनाने का तरीका
1. कंप्यूटर पर Android Studio इंस्टॉल करें (Android SDK सहित)।
2. Android Studio → **Open** → इस `AstroVeda-Android` फ़ोल्डर को चुनें।
3. Gradle Sync पूरा होने दें। पहली बार इंटरनेट की ज़रूरत होगी ताकि Android Gradle Plugin डाउनलोड हो सके।
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें।
5. APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## मौजूदा सीमाएँ – पब्लिक लॉन्च से पहले ज़रूरी
- यह Android Studio source project है; इस वातावरण में Android SDK/Gradle उपलब्ध नहीं था, इसलिए APK binary अभी compile नहीं की गई है।
- HTML में राशि-आधारित दैनिक टेक्स्ट और पंचांग/कुंडली के कुछ परिणाम अनुमानित/डेमो हैं। इन्हें सटीक ज्योतिषीय गणना न कहें।
- प्रीमियम बटन अभी demo unlock करता है; असली भुगतान के लिए Google Play Billing और backend entitlement आवश्यक हैं।
- कुंडली में अभी पूर्ण ग्रह-स्थिति/दशा गणना नहीं है। सार्वजनिक रिलीज़ से पहले प्रमाणित ephemeris/panchang engine और विशेषज्ञ सत्यापन जोड़ें।
- Google Fonts के लिए इंटरनेट चाहिए; offline अनुभव में system font fallback रहेगा।

## ऐप पहचान
- नाम: AstroVeda
- Application ID: `com.astroveda.app`
- Version: 1.0 (versionCode 1)
