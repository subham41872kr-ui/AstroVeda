# AstroVeda APK: सिर्फ Android मोबाइल से

यह GitHub Actions पर APK बनाता है; मोबाइल में Android Studio की जरूरत नहीं। यह APK अभी **debug/test** के लिए है, Play Store release नहीं।

1. GitHub पर मुफ्त अकाउंट बनाएं और नया **public या private** repository बनाएं, नाम `AstroVeda` रखें। README auto-create न करें।
2. मोबाइल में ZIP extract करें। **AstroVeda-Android फ़ोल्डर के अंदर की सारी files और folders** repository की root में अपलोड करें। खास तौर पर `.github/workflows/build-apk.yml` भी root में होना चाहिए। Android file manager hidden `.github` folder न दिखाए तो GitHub website में `Add file → Create new file` से `.github/workflows/build-apk.yml` बनाकर ZIP से workflow का content paste करें।
3. GitHub repo → **Actions** → **Build AstroVeda APK** → **Run workflow** → Run workflow। यदि workflow push पर शुरू हो चुका है तो उसे पूरा होने दें।
4. Build सफल होने के बाद Actions → सबसे नया successful run → **Artifacts** → `AstroVeda-debug-APK` डाउनलोड करें। ZIP extract करने पर `app-debug.apk` मिलेगा।
5. Android में `app-debug.apk` खोलकर Install करें। जरूरत पड़ने पर browser/file manager के लिए 'Install unknown apps' की अनुमति दें; इंस्टॉल के बाद अनुमति वापस बंद कर दें।

## महत्वपूर्ण
- GitHub upload के दौरान folder structure ज्यों का त्यों रखें। `app/` और `.github/` दोनों root में होने चाहिए।
- GitHub mobile web पर upload और hidden folder संभालना कठिन हो सकता है। Chrome → Desktop site चालू करना मदद कर सकता है।
- Debug APK सार्वजनिक वितरण के लिए नहीं है। Release APK के लिए सुरक्षित signing key, release build, testing और privacy disclosures जरूरी होंगे।
- अभी राशिफल, पंचांग, कुंडली और premium में demo/अनुमानित content है; सत्यापित गणना और असली भुगतान उपलब्ध नहीं।
